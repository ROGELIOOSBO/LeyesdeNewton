#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_2_clicked()
{
    QMessageBox msgBox;
    msgBox.setText("¡Su respuesta es incorrecta!, ya que la fuerzas son iguales y tiene la misma tensión por ambos lados.");
    msgBox.exec();
}

void MainWindow::on_pushButton_3_clicked()
{
    QMessageBox msgBox2;
    msgBox2.setText("¡Su respuesta es incorrecta!, ya que los objetos en un plano liso quedan fijos por la fuerza de gravedad y como no existe aceleracion no hay tensión.");
    msgBox2.exec();
}

void MainWindow::on_pushButton_5_clicked()
{
    QMessageBox msgBox3;
    msgBox3.setText("¡Su respuesta es incorrecta!, ya que en el sistema se puede dar un desequilibrio en la tensión por medio de la aceleracion.");
    msgBox3.exec();
}

void MainWindow::on_pushButton_4_clicked()
{
    QMessageBox msgBox4;
    msgBox4.setText("¡Su respuesta es correcta!, ya que si el sistema desciende la tensión es mayor.");
    msgBox4.exec();
}
